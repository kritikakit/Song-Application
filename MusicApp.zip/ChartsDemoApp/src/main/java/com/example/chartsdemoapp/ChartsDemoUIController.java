package com.example.chartsdemoapp;

import javafx.collections.FXCollections;   //importing necessary java classes
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.BorderPane;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import com.example.chartsdemoapp.DatabaseConnector;


public class ChartsDemoUIController implements Initializable {  // Controller class for handling the UI interactions and initializing the charts

    @FXML
    private BorderPane borderPane;   // This allows the controller to interact with the BorderPane component in the JavaFX UI.

    @Override       // The initialize method is called automatically after the FXML file has been loaded
    public void initialize(URL url, ResourceBundle rb) {
        // Initially show bar chart
        borderPane.setCenter(buildBarChart());    // Initially show the bar chart when the application starts
    }

    @FXML
    private void handleShowBarChart(ActionEvent event) {  // Event handler for showing the bar chart when the corresponding button is clicked
        borderPane.setCenter(buildBarChart());
    }

    @FXML
    private void handleShowPieChart(ActionEvent event) {     // Event handler for showing the pie chart when the button is clicked
        borderPane.setCenter(buildPieChart());
    }

    @FXML
    private void handleClose(ActionEvent event) {      // Event handler for closing the application
        System.exit(0);
    }

    private PieChart buildPieChart() {       // Method to build the pie chart with data from the database
        ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList();     // ObservableList to hold the data for the pie chart
        try {
            Connection connection = DatabaseConnector.getConnection();       // Establish a connection to the database
            Statement statement = connection.createStatement();
            String query = "SELECT genre, COUNT(*) AS count FROM sing GROUP BY genre";    // Query to get genre distribution
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {    // Loop through the result set and add data to the pie chart
                String genre = resultSet.getString("genre");      // Retrieve the genre from the current row of the result set
                int count = resultSet.getInt("count");     // Retrieve the count of songs for the current genre
                pieChartData.add(new PieChart.Data(genre, count));      // adds the genre and its count as a new data point to the pie chart data
            }

            resultSet.close();      // Close the result set and the statement
            statement.close();
            DatabaseConnector.closeConnection(connection);      // Closing the database connection
        } catch (SQLException e) {
            e.printStackTrace();
            showErrorAlert("Error", "Database Error", "Failed to fetch data from database.");   // shows the error alert if there is a database error

        }

        PieChart pieChart = new PieChart(pieChartData);     // Create a new PieChart with the data and set the title
        pieChart.setTitle("Genre Distribution");

        return pieChart;        // Return the constructed pie chart

    }

    private BarChart<String, Number> buildBarChart() {    // Method for building the bar chart with data from the database
        CategoryAxis xAxis = new CategoryAxis();         // Create the axes for the bar chart
        xAxis.setLabel("Song Title");    //x axis display the song title
        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("Duration (seconds)");  //y axis display the duartion in seconds

        BarChart<String, Number> barChart = new BarChart<>(xAxis, yAxis);  // Create a new BarChart with the axes
        ObservableList<BarChart.Series<String, Number>> barChartData = FXCollections.observableArrayList(); // ObservableList  for holding the data for the bar chart

        try {
            Connection connection = DatabaseConnector.getConnection();  // making connection to database
            Statement statement = connection.createStatement();
            String query = "SELECT title, duration FROM sing";    // Query for fetching song titles and their durations
            ResultSet resultSet = statement.executeQuery(query);

            BarChart.Series<String, Number> data = new BarChart.Series<>();   // Create a new series to hold the bar chart
            data.setName("Song Durations");

            while (resultSet.next()) {  // Iterate through each row in the result set returned by the database query
                String title = resultSet.getString("title");
                int duration = resultSet.getInt("duration");
                data.getData().add(new BarChart.Data<>(title, duration));
            }

            barChartData.add(data);     // Add the series to the bar chart data list

            resultSet.close();    // Close the result set and the statement

            statement.close();
            DatabaseConnector.closeConnection(connection);  //close the database connection
        } catch (SQLException e) {
            e.printStackTrace();
            showErrorAlert("Error", "Database Error", "Failed to fetch data from database."); //show an error alert if there is a database error
        }
         // The setData method sets the list of data series for the bar chart, which determines the bars that will be displayed.
        // barChartData contains the data series we created and populated with song title and duration data.
        // Hiding the legend helps to simplify the chart display since there is only one data series
        barChart.setData(barChartData);
        barChart.setLegendVisible(false);

        return barChart; // Return the constructed bar chart
    }

    private void showErrorAlert(String title, String headerText, String contentText) {      // Method for showing an error alert with the title, header, and content text

        Alert alert = new Alert(AlertType.ERROR);  // Create a new Alert of type ERROR

        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.setContentText(contentText);
        alert.showAndWait();  // Show the alert and wait for the user to close it

    }
}
