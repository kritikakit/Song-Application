package com.example.chartsdemoapp;

import java.sql.Connection; // Import necessary classes for sql connection
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnector {

    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/ammusic";    // JDBC URL, username and password for the MySQL database
    private static final String JDBC_USER = "root"; // Username for the database
    private static final String JDBC_PASSWORD = ""; // no password set

    // Establishes a connection to the database using the specified URL, username, and password.
    //return Connection object if the connection is successful.
    // throws SQLException if a database access error occurs.
    public static Connection getConnection() throws SQLException {

        return DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);  // Get the connection to the database
    }

    public static void closeConnection(Connection connection) {
        if (connection != null) { // Check if connection is not null
            try {
                connection.close(); // Attempt to close the connection
            } catch (SQLException e) {
                e.printStackTrace(); // Print the stack trace if an error occurs
            }
        }
    }
}



