package com.example.chartsdemoapp;

import javafx.application.Application;  //importing  necessary java classes
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.image.Image;

import java.io.IOException;

public class ChartsDemoApp extends Application {    // Main class of the application (extend the JavaFX Application class)

    @Override  // The start method
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("hello-view.fxml")); // Loading the FXML file to create the GUI
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root, 800, 600); // Creating a Scene with the loaded FXML content The Scene object is the container for all content in the JavaFX application
        stage.setTitle("Music Application");  //Setting title of the main window and setting it to stage.
        Image icon = new Image(ChartsDemoApp.class.getResourceAsStream("/icon.png"));  //Loading the icon for the application.
        stage.getIcons().add(icon);
        stage.setScene(scene);  // set scene for stage
        stage.show();  //show main window
    }

    public static void main(String[] args) {  //Main method for launching javafx application
        launch();
    }
}

